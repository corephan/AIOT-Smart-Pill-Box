import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Login.css';

function Login({ setUser }) {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = () => {
    const users = JSON.parse(localStorage.getItem('users')) || [];
    const existingUser = users.find(user => user.email === email && user.password === password);

    if (existingUser) {
      localStorage.setItem('user', JSON.stringify(existingUser));
      setUser(existingUser);
      navigate('/');
    } else {
      setError('Thông tin đăng nhập không chính xác.');
    }
  };

  return (
    <div className="login-wrapper">
      <div className="form-box">
        <h2>🔐 Đăng nhập</h2>
        {error && <p style={{ color: 'red' }}>{error}</p>}
        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <input
          type="password"
          placeholder="Mật khẩu"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        <button onClick={handleLogin}>Đăng nhập</button>
        <p style={{ marginTop: '10px' }}>
          <a href="/reset-password" style={{ color: '#007bff', textDecoration: 'underline' }}>
            Quên mật khẩu?
          </a>
        </p>
      </div>
    </div>
  );
}

export default Login;
