import React, { useState } from 'react';
import './News.css';
import newsData from './newsData';

function News() {
  const categories = Object.keys(newsData);
  const [activeCategory, setActiveCategory] = useState(categories[0]);

  const handleArticleClick = (article) => {
    const viewed = JSON.parse(localStorage.getItem('viewedNews')) || [];
    const isDuplicate = viewed.some((item) => item.link === article.link);
    if (!isDuplicate) {
      viewed.push(article);
      localStorage.setItem('viewedNews', JSON.stringify(viewed));
    }
  };

  return (
    <div className="news-page">
      <h2>Tin Tức Y Tế</h2>
      <div className="news-tabs">
        {categories.map((cat) => (
          <button
            key={cat}
            className={activeCategory === cat ? 'active' : ''}
            onClick={() => setActiveCategory(cat)}
          >
            {cat}
          </button>
        ))}
      </div>

      <div className="news-list">
        {newsData[activeCategory].map((article, idx) => (
          <div key={idx} className="news-card">
            <a
              href={article.link}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => handleArticleClick(article)}
            >
              <img src={article.image} alt={article.title} />
              <p>{article.title}</p>
            </a>
          </div>
        ))}
      </div>
    </div>
  );
}

export default News;