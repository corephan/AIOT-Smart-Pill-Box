import requests, json 

uid = "9WyWRTbUkqOKgr4Zlvo3wqoijKg2"

payload = {
    "email": "104240618@student.vgu.edu.vn",
    "password": "11111111@Aa",
    "medical_name": "Paracetamol",
    "medical_amount": 2,
    "medical_time": "18:00",
    "medical_duration_days": 5,
    "uid": uid,
    "phone_number": "0383969099",
    "user_name": "Test User",
    "username": "testuser",
    "device_udid": "123456",
    "device_uid": "123456",
    "note": "This is a small pill reminders",
    "dose": "Some kinda amount"
}


with requests.Session() as session:
    response = session.post("http://127.0.0.1:5000/login", json=payload)
    print(response.json())
    response = session.post("http://127.0.0.1:5000/medical_management", json=payload)
    print(response.json())