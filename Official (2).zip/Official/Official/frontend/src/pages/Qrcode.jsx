import React, { useEffect, useRef } from 'react';
import QRCode from 'qrcode';
import './Qrcode.css';

function Qrcode() {
  const canvasRef = useRef(null);

  useEffect(() => {
    const user = JSON.parse(localStorage.getItem('user'));
    if (user && canvasRef.current) {
      const data = `Tên: ${user.username}\nEmail: ${user.email}\nSĐT: ${user.phone}`;
      QRCode.toCanvas(canvasRef.current, data, { width: 250 }, (err) => {
        if (err) console.error(err);
      });
    }
  }, []);

  return (
    <div className="qrcode-container">
      <h2>🔳 Mã QR của bạn</h2>
      <p>Quét mã này để truy xuất nhanh thông tin tài khoản.</p>
      <canvas ref={canvasRef} />
    </div>
  );
}

export default Qrcode;